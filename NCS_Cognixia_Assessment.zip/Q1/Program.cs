﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;

            Console.Write("Input the number of elements to be stored in the array: ");
            int input = Convert.ToInt32(Console.ReadLine());

            for(int i = 0; i < input; i++)
            {
                Console.Write("Element - {0}: ", i);
                sum += Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("Sum of all elements stored in the array is : {0}", sum);
        }
    }
}
