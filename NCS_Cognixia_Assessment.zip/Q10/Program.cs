﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input number of strings to store in the array: ");
            int inputNum = Convert.ToInt32(Console.ReadLine());
            string[] arr = new string[inputNum];

            for (int i = 0; i < inputNum; i++)
            {
                Console.Write("Element[{0}] : ", i);
                arr[i] = Console.ReadLine();

            }
            string newStr = String.Join(", ", arr.Select(x => x.ToString()).ToArray());

            Console.WriteLine("Here is the string below created with elements of the above array");
            Console.WriteLine(newStr);
        }
    }
}
