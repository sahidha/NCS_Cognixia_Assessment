﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string firstFileName = @"mytest.txt";
            string secondFileName = @"mynewtest.txt";

            if (File.Exists(firstFileName))
            {
                File.Delete(firstFileName);
            }
            string myText = "Hello and Welcome\nIt is the first content\nof the text file mytest.txt";

            File.WriteAllText(firstFileName, myText);

            string readText = File.ReadAllText(firstFileName);
            Console.WriteLine("Here is the content of the file {0}", firstFileName);
            Console.WriteLine(readText);
            Console.WriteLine();

            File.Copy(firstFileName, secondFileName, true);
            Console.WriteLine("The file {0} is successfully copied to the name {1} in the same directory");
            Console.WriteLine("Here is the content of the file {0}", secondFileName);
            string readNewText = File.ReadAllText(secondFileName);
            Console.WriteLine(readNewText);
        }
    }
}
