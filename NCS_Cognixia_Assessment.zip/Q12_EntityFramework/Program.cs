﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q12_EntityFramework
{
    internal class Program
    {
        static void Main(string[] args)
        {
            NCS2022Entities context = new NCS2022Entities();

            //Add records
            Library book1 = new Library();
            book1.BookName = "Divergent";
            book1.AuthorName = "Veronica Roth";
            DateTime dt1 = new DateTime(2014, 3, 21);
            book1.PublishingDate = dt1;
            book1.Price = Convert.ToDecimal(18.5);

            context.Libraries.Add(book1);
            context.SaveChanges();
            Console.WriteLine("Book {0} is added", book1.BookName);

            //Display record
            var displayBook = from books in context.Libraries
                              select books;

            foreach (var book in displayBook)
            {
                Console.WriteLine("Book ID: {0} | Book Name: {1} | Author: {2} | Publish Date: {3} | Price:$ {4}", book.BookID,book.BookName,book.AuthorName,book.PublishingDate,book.Price);
            }

            //Update record
            Console.WriteLine("Which book price you want to update?");
            //Updating price default to 20
            int updateInput = Convert.ToInt32(Console.ReadLine());

            Library updateBook = context.Libraries.FirstOrDefault(x => x.BookID == updateInput);
            updateBook.Price = Convert.ToDecimal(20);

            context.SaveChanges();
            Console.WriteLine("{0}'s Price is updated!", updateBook.BookName);
            //Delete record
            Console.WriteLine("Which book (ID) you want to delete?");
            int deleteInput = Convert.ToInt32(Console.ReadLine());

            Library deleteBook = context.Libraries.FirstOrDefault(x => x.BookID.Equals(deleteInput));
            context.Libraries.Remove(deleteBook);
            context.SaveChanges();
            Console.WriteLine("{0} is deleted! ", deleteBook.BookName);
        }
    }
}
