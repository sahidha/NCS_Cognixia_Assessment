﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q13_LINQ_To_DataSet
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string connString = @"Data Source=SAHIDHA\SQLEXPRESS;Initial Catalog=NCS2022;Integrated Security=True";

            string sqlSelect = "SELECT * FROM Library;";
            SqlDataAdapter da = new SqlDataAdapter(sqlSelect, connString);
            da.TableMappings.Add("Table", "Library");

            DataSet ds = new DataSet();
            da.Fill(ds);

            DataTable lib = ds.Tables["Library"];
            var book = from b in lib.AsEnumerable()
                       select b;
            foreach (DataRow dr in book)
            {
                Console.WriteLine("Book ID: {0} | Book Name: {1} | Author: {2} | Publish Date: {3} | Price:$ {4}", dr.Field<int>("BookID"), dr.Field<string>("BookName"), dr.Field<string>("AuthorName"), dr.Field<DateTime>("PublishingDate"), dr.Field<decimal>("Price"));

            }
        }
    }
}
