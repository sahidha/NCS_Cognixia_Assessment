﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q13_LINQ_To_SQL
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string connString = @"Data Source=SAHIDHA\SQLEXPRESS;Initial Catalog=NCS2022;Integrated Security=True";
            LinqSqlDataContext context = new LinqSqlDataContext(connString);

            var viewBooks = from book in context.Libraries
                            select book;

            foreach (var book in viewBooks)
            {
                Console.WriteLine("Book ID: {0} | Book Name: {1} | Author: {2} | Publish Date: {3} | Price:$ {4}", book.BookID, book.BookName, book.AuthorName, book.PublishingDate, book.Price);
            }
        }
    }
}
