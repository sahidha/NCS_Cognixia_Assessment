﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[100];
            Console.Write("Input the number of elements to be stored in the array: ");
            int input = Convert.ToInt32(Console.ReadLine());

            for(int i = 0; i < input; i++)
            {
                Console.Write("Element - {0}: ",i);
                array[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("The unique elements found in the array are: ");
            for(int i = 0; i < input; i++)
            {
                int count = 0;

                for(int j = 0; j < i-1; j++)
                {
                    if(array[i] == array[j])
                    {
                        count++;
                    }
                }

                for(int k = i + 1; k < input; k++)
                {
                    if(array[i] == array[k])
                    {
                        count++;
                    }

                    if(array[i] == array[i + 1])
                    {
                        i++;
                    }
                }

                if(count == 0)
                {
                    Console.Write("{0} ", array[i]);
                }
            }
        }
    }
}
