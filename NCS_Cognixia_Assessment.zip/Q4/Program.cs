﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string message = "Password entered successfully!";

            Console.Write("Input a username: ");
            string username = Console.ReadLine();

            Console.Write("Input a password: ");
            string password = Console.ReadLine();

            if(username == "user" && password == "pass")
            {
                Console.WriteLine(message);
            }
            else if (username == "abcd" && password == "1234")
            {
                Console.WriteLine(message);
            }
            else
            {
                Console.WriteLine("Username/password entered wrongly");
            }
        }
    }
}
