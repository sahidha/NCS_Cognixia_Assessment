﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Globalization;

namespace Q5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] cultureTypes = { "en-US", "se-SE" }; //English US & Sami North Sweden
            string[] set1 = { "case", "encyclopedia" };
            string[] set2 = { "CASE", "ENCYCLOPEDIA" };

            StringComparison[] comparisons = (StringComparison[])Enum.GetValues(typeof(StringComparison));

            foreach(var c in cultureTypes)
            {
                Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(c);

                Console.WriteLine("For Culture: {0} ", CultureInfo.CurrentCulture.Name);
                for(int i= 0; i < set1.GetUpperBound(0); i++)
                {
                    foreach(var compare in comparisons)
                    {
                        Console.WriteLine("{0} = {1} ({2}): {3}", set1[i],set2[i],compare, String.Equals(set1[i],set2[i],compare));
                    }
                }
            }
        }
    }
}
