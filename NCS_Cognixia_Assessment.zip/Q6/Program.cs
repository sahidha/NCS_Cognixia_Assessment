﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Original integer value: ");
            int value = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Roman numerals of the said integer value: ");
            Console.WriteLine(intToRoman(value));
        }

        public static string intToRoman (int n) {
            int[] intValue = { 1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1 };
            string[] romanSymbols = { "M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I" };

            var r = new StringBuilder();

            var index = 0;

            while (n != 0)
            {
                if( n >= intValue[index])
                {
                    n-= intValue[index];
                    r.Append(romanSymbols[index]);
                }
                else
                {
                    index++;
                }
            }
            return r.ToString();
        }
    }
}
