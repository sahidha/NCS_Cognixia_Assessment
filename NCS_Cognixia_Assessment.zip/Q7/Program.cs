﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q7
{
    class Permutation
    {
        public void swapNum(ref int a, ref int b)
        {
            int temp = a;
            a = b;
            b = temp;
        }

        public void permutate(int[] arr, int index, int num)
        {

            if (index == num)
            {
                for (int i = 0; i <= num; i++)
                {
                    Console.Write("{0}", arr[i]);
                }
                Console.Write(" ");
            }
            else
            {
                for (int i = index; i <= num; i++)
                {
                    swapNum(ref arr[index], ref arr[i]);
                    permutate(arr, index + 1, num);
                    swapNum(ref arr[index], ref arr[i]);
                }
            }

        }
    }
    internal class Program
    {
        public static void Main(string[] args)
        {
            Console.Write("Input the number of elements to store in the array[maximum 5 digits]: ");
            int n = Convert.ToInt32(Console.ReadLine());
            int[] array = new int[n];

            for (int i = 0; i < n; i++)
            {
                Console.Write("Element - {0} :", i);
                array[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("The Permutations with a combination of {0} digits are : ", n);
            Permutation permute = new Permutation();
            permute.permutate(array, 0, n - 1);
            Console.WriteLine();
        }

       
    }
}
