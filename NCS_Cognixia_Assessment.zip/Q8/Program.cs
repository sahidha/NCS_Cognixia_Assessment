﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input the string: ");
            var inputString = Console.ReadLine();

            var freq = from c in inputString
                       group c by c into x
                       select x;

            foreach(var c in freq)
            {
                Console.WriteLine("Character {0}: {1} times", c.Key, c.Count());
            }
        }
    }
}
