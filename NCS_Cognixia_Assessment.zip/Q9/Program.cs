﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] cities = { "ROME", "LONDON", "NAIROBI", "CALIFORNIA", "ZURICH", "NEW DELHI", "AMSTERDAM", "ABU DHABI", "PARIS" };
            char c;

            Console.Write("Input starting character for the string :");
            c = Convert.ToChar(Console.ReadLine());
            string start = c.ToString();
            Console.Write("Input ending character for the string :");
            c = Convert.ToChar(Console.ReadLine());
            string end = c.ToString();

            var city = from x in cities
                       where x.StartsWith(start)
                       where x.EndsWith(end)
                       select x;
            foreach (var item in city)
            {
                Console.WriteLine("The city starting with {0} and ending with {1} is: {2}", start, end, item);
            }
            
        }
    }
}
